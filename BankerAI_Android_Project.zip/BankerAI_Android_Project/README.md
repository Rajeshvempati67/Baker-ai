# BankerAI Android Project

This Android Studio project wraps the BankerAI customer-profiling practice website in a native Android WebView.

Features included:
- You are the BANKER; AI is the CUSTOMER.
- Customer profiling practice flow.
- Microphone permission.
- In-app web audio/recording support.
- Portrait phone layout.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated debug APK on your Android phone.

Note: this project is ready to compile, but the current environment does not contain the Android SDK/Gradle toolchain needed to produce the binary APK here.
